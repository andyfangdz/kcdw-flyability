"""Read immutable WN3 global chunks; retain only nine points around KCDW."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
import zstandard
from kcdw.weathernext3_zarr import GrpcStore, ObjectInfo

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / 'chunks'
CACHE.mkdir(exist_ok=True)
manifest = json.loads((ROOT / 'manifest.json').read_text())
assert len(manifest['objects']) == 3840
assert manifest['total_compressed_bytes'] < 14_000_000_000
with np.load(ROOT / 'coordinates.npz', allow_pickle=False) as coordinates:
    lat = coordinates['lat_0p25'].copy()
    lon = (coordinates['lon_0p25'].copy() + 180) % 360 - 180
iy = int(np.argmin(abs(lat - 40.8752)))
ix = int(np.argmin(abs(lon + 74.2814)))
assert lat[iy] == 41 and lon[ix] == -74.25
lat_indices = np.arange(iy - 1, iy + 2)
lon_indices = np.arange(ix - 1, ix + 2)


class EnsembleStore(GrpcStore):
    @property
    def bucket_path(self):
        return 'projects/_/buckets/weathernext3_spatial'


store = EnsembleStore(project=manifest['billing_project'])
bounds = {
    'temperature': (150, 350), 'specific_humidity': (0, .10),
    'u_component_of_wind': (-200, 200), 'v_component_of_wind': (-200, 200),
    'geopotential': (-10000, 120000),
}


def fetch(item):
    target = CACHE / f"{item['member']:02d}-{item['lead']}-{item['level_hpa']}-{item['variable']}.json"
    if target.exists():
        proof = json.loads(target.read_text())
        assert proof['object'] == item
        retained = np.array(proof['values'], dtype='<f4')
        assert hashlib.sha256(retained.tobytes()).hexdigest() == proof['retained_sha256']
        return proof
    info = ObjectInfo(size=item['size'], generation=item['generation'], crc32c=item['crc32c'])
    assert 0 < info.size < 4_200_000
    # GrpcStore verifies complete compressed-object size and CRC32C.
    encoded, _ = store.read_object(item['name'], info)
    expected = 721 * 1440 * 4
    decoded = zstandard.ZstdDecompressor().decompress(encoded, max_output_size=expected)
    assert len(decoded) == expected
    grid = np.frombuffer(decoded, dtype='<f4').reshape(721, 1440)
    retained = grid[np.ix_(lat_indices, lon_indices)].copy()
    assert retained.shape == (3, 3) and np.isfinite(retained).all()
    lower, upper = bounds[item['variable']]
    assert retained.min() >= lower and retained.max() <= upper
    proof = dict(object=item, values=retained.tolist(),
                 source_sha256=hashlib.sha256(encoded).hexdigest(),
                 retained_sha256=hashlib.sha256(retained.tobytes()).hexdigest(),
                 retrieved_at=datetime.now(timezone.utc).isoformat())
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(proof) + '\n')
    temporary.replace(target)
    return proof


items = [o for o in manifest['objects'] if o['member'] == 0] if '--pilot' in sys.argv else manifest['objects']
started = time.monotonic()
results = []
with ThreadPoolExecutor(max_workers=12) as pool:
    jobs = [pool.submit(fetch, item) for item in items]
    for job in as_completed(jobs):
        results.append(job.result())
        if len(results) % 100 == 0 or len(results) == len(items):
            print('EXTRACTED', len(results), '/', len(items), 'seconds', round(time.monotonic() - started), flush=True)

if len(results) == 3840:
    arrays = {v: np.full((64, 2, 6, 3, 3), np.nan, dtype=np.float32) for v in manifest['variables']}
    seen = set()
    for proof in results:
        item = proof['object']
        key = (item['variable'], item['member'], item['lead'], item['level_hpa'])
        assert key not in seen
        seen.add(key)
        arrays[item['variable']][item['member'], manifest['leads'].index(item['lead']),
                                manifest['levels_hpa'].index(item['level_hpa'])] = proof['values']
    assert all(np.isfinite(a).all() for a in arrays.values())
    np.savez_compressed(ROOT / 'profiles.npz', **arrays, member=np.arange(64),
                        valid_time=manifest['valid_times'], pressure_hpa=manifest['levels_hpa'],
                        latitude=lat[lat_indices], longitude=lon[lon_indices])
    metadata = dict(init=manifest['init'], valid_times=manifest['valid_times'], members=64,
                    levels_hpa=manifest['levels_hpa'], variables=manifest['variables'],
                    dimension_names=['member', 'valid_time', 'pressure_hpa', 'latitude', 'longitude'],
                    nearest_point={'latitude': float(lat[iy]), 'longitude': float(lon[ix])},
                    requested_point={'latitude': 40.8752, 'longitude': -74.2814},
                    source_bucket=manifest['bucket'], source_compressed_bytes=manifest['total_compressed_bytes'],
                    profile_sha256=hashlib.sha256((ROOT / 'profiles.npz').read_bytes()).hexdigest(),
                    manifest_sha256=hashlib.sha256((ROOT / 'manifest.json').read_bytes()).hexdigest(),
                    completed_at=datetime.now(timezone.utc).isoformat())
    (ROOT / 'extraction.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps(metadata), flush=True)
else:
    for variable in manifest['variables']:
        selected = [p for p in results if p['object']['variable'] == variable and p['object']['lead'] == 108]
        print(variable, [(p['object']['level_hpa'], p['values'][1][1]) for p in sorted(selected, key=lambda p: -p['object']['level_hpa'])], flush=True)
