from concurrent.futures import ThreadPoolExecutor,as_completed
from dataclasses import asdict
from datetime import datetime,timedelta,timezone
from pathlib import Path
import hashlib,json
import numpy as np
import zstandard
from kcdw.weathernext3_zarr import GrpcStore
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
SOURCE=REPO/'var/research/wn3-members-20260920'
class EnsembleStore(GrpcStore):
    @property
    def bucket_path(self):return 'projects/_/buckets/weathernext3_spatial'
store=EnsembleStore(project='aviation-486817')
PREFIX='weathernext_3_0_0/zarr/2026_to_present/20260920_00hr_01_preds/predictions.zarr'
metadata_file=ROOT/'zarr.json'
raw=(metadata_file if metadata_file.exists() else SOURCE/'20260920T00Z-zarr.json').read_bytes();metadata_file.write_bytes(raw)
META=json.loads(raw)['consolidated_metadata']['metadata']
coords={}
for key in ('sample','lead_time','level','lat_0p25','lon_0p25'):
    m=META[key];name=f'{PREFIX}/{key}/c/0';info=store.info(name);assert info.size<100000
    raw,_=store.read_object(name,info);decoded=zstandard.ZstdDecompressor().decompress(raw)
    values=np.frombuffer(decoded,dtype={'float32':'<f4','int64':'<i8','int32':'<i4'}[m['data_type']]).copy()
    assert list(values.shape)==m['shape'];coords[key]=values
    print(key,values.tolist() if values.size<100 else [float(values.min()),float(values.max())],flush=True)
np.savez_compressed(ROOT/'coordinates.npz',**coords)
assert np.array_equal(coords['sample'],np.arange(64))
assert np.array_equal(coords['lead_time'],np.arange(6,361,6))
assert np.allclose(coords['lat_0p25'],np.arange(-90,90.01,.25),rtol=0,atol=1e-5)
assert np.allclose(coords['lon_0p25'],np.arange(0,360,.25),rtol=0,atol=1e-5)
variables={'temperature':'K','specific_humidity':'kg kg**-1','u_component_of_wind':'m s**-1','v_component_of_wind':'m s**-1','geopotential':'m**2 s**-2'}
levels=[1000,925,850,700,600,500];leads=[108,114]
for var,unit in variables.items():
 m=META[var]
 assert m['shape']==[64,60,13,721,1440] and m['chunk_grid']['configuration']['chunk_shape']==[1,1,1,721,1440]
 assert m['dimension_names']==['sample','lead_time','level','lat_0p25','lon_0p25'] and m['data_type']=='float32'
 assert m['attributes']['units']==unit
 assert m['codecs']==[{'name':'bytes','configuration':{'endian':'little'}},{'name':'zstd','configuration':{'level':0,'checksum':False}}]

def get_info(args):
 var,lead,level,member=args
 hi=int(np.flatnonzero(coords['lead_time']==lead)[0]);zi=int(np.flatnonzero(coords['level']==level)[0])
 name=f'{PREFIX}/{var}/c/{member}/{hi}/{zi}/0/0';info=store.info(name)
 return dict(variable=var,unit=variables[var],lead=lead,level_hpa=level,member=member,name=name,**asdict(info))
objects=[]
with ThreadPoolExecutor(max_workers=12) as pool:
 jobs=[pool.submit(get_info,(v,h,p,m)) for v in variables for h in leads for p in levels for m in range(64)]
 for f in as_completed(jobs):
  objects.append(f.result())
  if len(objects)%500==0:print('INVENTORIED',len(objects),'/',len(jobs),flush=True)
objects.sort(key=lambda o:(o['member'],o['lead'],o['level_hpa'],o['variable']))
# Verify actual datetime coordinate chunks for each native pressure-level valid time.
for lead in leads:
 idx=int(np.flatnonzero(coords['lead_time']==lead)[0]);name=f'{PREFIX}/datetime/c/{idx}'
 info=store.info(name);raw,_=store.read_object(name,info)
 dt=np.frombuffer(zstandard.ZstdDecompressor().decompress(raw),dtype='<i8')[0]
 expected=datetime(2026,9,20,tzinfo=timezone.utc)+timedelta(hours=lead)
 assert int(dt)==int(expected.timestamp())*1000000000
manifest=dict(init='2026-09-20T00:00:00Z',bucket='weathernext3_spatial',billing_project='aviation-486817',variables=variables,levels_hpa=levels,leads=leads,valid_times=['2026-09-24T12:00:00Z','2026-09-24T18:00:00Z'],members=64,objects=objects,total_compressed_bytes=sum(o['size'] for o in objects),metadata_sha256=hashlib.sha256((ROOT/'zarr.json').read_bytes()).hexdigest(),checked_at=datetime.now(timezone.utc).isoformat())
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('TOTAL',len(objects),'objects',manifest['total_compressed_bytes']/1e9,'GB',manifest['total_compressed_bytes']/2**30*.12,'USD estimated egress',flush=True)
