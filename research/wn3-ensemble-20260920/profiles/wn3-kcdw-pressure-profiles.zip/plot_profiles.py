"""Standalone, native-time WN3 ensemble profiles with member spread."""
from pathlib import Path
import json
import os
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parents[2] / 'charts/.matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
import numpy as np

ROOT = Path(__file__).resolve().parent
data = np.load(ROOT / 'derived-profiles.npz', allow_pickle=False)
diagnostics = json.loads((ROOT / 'diagnostics.json').read_text())
p = data['pressure_hpa']
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': '#b8c3cd', 'text.color': '#182a3b',
                     'axes.labelcolor': '#34485b', 'xtick.color': '#526171',
                     'ytick.color': '#526171', 'savefig.facecolor': 'white'})
fig, axes = plt.subplots(2, 3, figsize=(14, 10.4), sharey=True)
fig.subplots_adjust(left=.085, right=.91, bottom=.16, top=.825, hspace=.32, wspace=.22)
fig.text(.06, .957, 'WN3: dry air above KCDW, stronger winds aloft', fontsize=23, weight='bold')
fig.text(.06, .92, 'Thursday, September 24, 2026  •  Native profiles bracketing the 10 a.m.–noon EDT flight window', fontsize=12)
fig.text(.06, .892, '64 members  •  Initialized September 20 at 00Z  •  Nearest 0.25° point: 41.00°N, 74.25°W', fontsize=11, color='#596b7b')

for hi, (time_label, color) in enumerate([('8 a.m. EDT / 12Z', '#176a99'), ('2 p.m. EDT / 18Z', '#b95a1d')]):
    rows = [r for r in diagnostics['rows'] if r['valid_time'] == str(data['valid_time'][hi])]
    for col, ax in enumerate(axes[hi]):
        ax.set_yscale('log')
        ax.set_ylim(1030, 485)
        ax.yaxis.set_major_locator(FixedLocator(p))
        ax.yaxis.set_major_formatter(FixedFormatter([str(v) for v in p]))
        ax.yaxis.set_minor_locator(NullLocator())
        ax.grid(axis='y', color='#dbe2e8', linewidth=.8)
        ax.grid(axis='x', color='#edf1f4', linewidth=.65)
        if hi == 0:
            ax.set_title(['Temperature', 'Relative humidity', 'Wind speed'][col], loc='left', fontsize=14, pad=14, weight='bold')
    axes[hi, 0].set_ylabel(f'{time_label}\nPressure (hPa)', labelpad=13, weight='bold', color=color)
    for name, linestyle, alpha in [('temperature_c', '-', .18)]:
        values = data[name][:, hi, :, 1, 1]
        low, med, high = np.quantile(values, [.1, .5, .9], axis=0)
        axes[hi, 0].fill_betweenx(p, low, high, color=color, alpha=alpha, linewidth=0)
        axes[hi, 0].plot(med, p, linestyle=linestyle, color=color, linewidth=2.2, marker='o', markersize=4)
    axes[hi, 0].axvline(0, color='#98a8b6', linewidth=1, linestyle=':')
    axes[hi, 0].set_xlim(-25, 25)
    axes[hi, 0].set_xticks([-20, -10, 0, 10, 20])
    axes[hi, 0].set_xlabel('°C')
    for col, name, label in [(1, 'relative_humidity_water_pct', '% over liquid water'), (2, 'wind_speed_kt', 'knots')]:
        values = data[name][:, hi, :, 1, 1]
        low, med, high = np.quantile(values, [.1, .5, .9], axis=0)
        axes[hi, col].fill_betweenx(p, low, high, color=color, alpha=.18, linewidth=0)
        axes[hi, col].plot(med, p, color=color, linewidth=2.2, marker='o', markersize=4)
        axes[hi, col].set_xlabel(label)
    axes[hi, 1].set_xlim(0, 105)
    axes[hi, 1].set_xticks([0, 20, 40, 60, 80, 100])
    axes[hi, 1].axvline(80, linestyle=':', color='#8c9daa', linewidth=1)
    axes[hi, 2].set_xlim(0, 42)
    axes[hi, 2].set_xticks([0, 10, 20, 30, 40])
    for pi, row in enumerate(rows):
        axes[hi, 2].annotate(f"{row['wind_direction']['mean_vector_from_deg_true']:03.0f}°",
                            xy=(row['wind_speed_kt']['p90'] + 1.5, p[pi]),
                            va='center', color=color, fontsize=9)
    secondary = axes[hi, 2].secondary_yaxis('right')
    secondary.set_yticks(p, labels=[f"{int(round(r['height_ft_msl']['median'] / 100) * 100):,}" for r in rows])
    secondary.yaxis.set_minor_locator(NullLocator())
    secondary.set_ylabel('Approx. height (ft MSL)', labelpad=12)
    secondary.spines['right'].set_visible(False)

legend = [Line2D([0], [0], color='#34485b', linewidth=2.2, label='Member median'),
          Line2D([0], [0], color='#aebfcc', linewidth=10, alpha=.45, label='10th–90th percentiles')]
fig.legend(handles=legend, loc='lower left', bbox_to_anchor=(.06, .088), frameon=False, ncol=3, fontsize=10)
fig.text(.06, .065, 'Wind labels: direction FROM, degrees true, from ensemble-mean U/V. RH is derived from each member’s temperature and specific humidity.', fontsize=9, color='#596b7b')
fig.text(.06, .044, 'Six pressure levels cannot resolve thin stratus or diagnose a ceiling. Lines connect sampled levels; no hourly pressure profiles were interpolated.', fontsize=9, color='#596b7b')
fig.text(.06, .023, 'Source: Google WeatherNext 3 raw ensemble Zarr (weathernext3_spatial). Heights derived from geopotential; bands describe this ensemble’s spread.', fontsize=9, color='#596b7b')
fig.savefig(ROOT / 'wn3-kcdw-pressure-profiles.png', dpi=240)
fig.savefig(ROOT / 'wn3-kcdw-pressure-profiles.svg')
print(ROOT / 'wn3-kcdw-pressure-profiles.png')
