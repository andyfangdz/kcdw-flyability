"""Member-paired thermodynamic/wind diagnostics; no time interpolation."""
from datetime import datetime, timezone
from pathlib import Path
import csv
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
EPSILON = .622
KNOTS = 3600 / 1852
with np.load(ROOT / 'profiles.npz', allow_pickle=False) as raw:
    source = {k: raw[k].copy() for k in raw.files}
assert np.array_equal(source['member'], np.arange(64))
pressure = source['pressure_hpa'][None, None, :, None, None].astype(float)
t = source['temperature'].astype(float)
tc = t - 273.15
q = source['specific_humidity'].astype(float)
u = source['u_component_of_wind'].astype(float)
v = source['v_component_of_wind'].astype(float)
z = source['geopotential'].astype(float) / 9.80665
e = pressure * q / (EPSILON + (1 - EPSILON) * q)
es = 6.112 * np.exp(17.67 * tc / (tc + 243.5))
rh = 100 * e / es
positive_moisture = e > 0
td = np.full(e.shape, np.nan)
log_e = np.log(e[positive_moisture] / 6.112)
td[positive_moisture] = 243.5 * log_e / (17.67 - log_e)
speed = np.hypot(u, v) * KNOTS
direction = np.degrees(np.arctan2(-u, -v)) % 360
derived = dict(temperature_c=tc, dewpoint_c=td, relative_humidity_water_pct=rh,
               height_ft_msl=z / .3048, wind_speed_kt=speed, wind_from_deg_true=direction,
               specific_humidity_g_kg=q * 1000)
assert all(np.isfinite(a).all() for name, a in derived.items() if name != 'dewpoint_c')
assert np.all(np.diff(z, axis=2) > 0), 'Geopotential height must rise as pressure falls.'
assert np.all((e >= 0) & (e < pressure))

# Independent formulation check: Hyland & Wexler 1983 over liquid water.
es_hw = np.exp(-.58002206e4 / t + .13914993e1 - .48640239e-1 * t
               + .41764768e-4 * t**2 - .14452093e-7 * t**3 + .65459673e1 * np.log(t)) / 100
rh_hw = 100 * e / es_hw
# Recover q via mixing ratio from vapor pressure, independent of the forward expression.
mixing_ratio = EPSILON * e / (pressure - e)
q_recovered = mixing_ratio / (1 + mixing_ratio)
assert np.max(np.abs(q_recovered - q)) < 1e-14
assert np.nanmax(np.abs(100 * 6.112 * np.exp(17.67 * td / (td + 243.5)) / es - rh)) < 1e-10
# Diagnose approximate hydrostatic consistency; a two-level mean misses intervening curvature.
tv = t * (1 + (1 / EPSILON - 1) * q)
dz_hydrostatic = (287.05 / 9.80665 * (tv[:, :, :-1] + tv[:, :, 1:]) / 2
                  * np.log(pressure[:, :, :-1] / pressure[:, :, 1:]))
dz_actual = np.diff(z, axis=2)


def summary(values):
    values = np.asarray(values)
    values = values[np.isfinite(values)]
    return dict(count=int(values.size), mean=float(np.mean(values)), p10=float(np.quantile(values, .1)),
                median=float(np.median(values)), p90=float(np.quantile(values, .9)),
                min=float(np.min(values)), max=float(np.max(values)))


rows = []
for hi, valid_time in enumerate(source['valid_time']):
    for pi, level in enumerate(source['pressure_hpa']):
        row = dict(valid_time=str(valid_time), pressure_hpa=int(level), members=64)
        for name, values in derived.items():
            if name == 'wind_from_deg_true':
                continue
            row[name] = summary(values[:, hi, pi, 1, 1])
        uu = u[:, hi, pi, 1, 1]; vv = v[:, hi, pi, 1, 1]
        mean_direction = float(np.degrees(np.arctan2(-uu.mean(), -vv.mean())) % 360)
        offsets = (direction[:, hi, pi, 1, 1] - mean_direction + 180) % 360 - 180
        row['wind_direction'] = dict(mean_vector_from_deg_true=mean_direction,
                                     p10_unwrapped_deg=mean_direction + float(np.quantile(offsets, .1)),
                                     p90_unwrapped_deg=mean_direction + float(np.quantile(offsets, .9)))
        for threshold in (80, 90, 95, 100):
            row[f'members_rh_ge_{threshold}'] = int(np.sum(rh[:, hi, pi, 1, 1] >= threshold))
        row['members_zero_specific_humidity'] = int(np.sum(q[:, hi, pi, 1, 1] == 0))
        rows.append(row)

surface_cache = ROOT / 'surface-context-input.json'
if not surface_cache.exists():
    surface_cache = REPO / 'var/wn3-bigquery/0e4fb4acdcc85b7950cd2d4417aa8943d72685cfdd95cc929d1450d304d8e597.json'
surface_data = json.loads(surface_cache.read_text())
assert surface_data['identity']['run'] == '2026-09-20T00:00:00+00:00'
surface = []
for item in surface_data['rows']:
    valid_time = item['valid_time']
    if not '2026-09-24T12:00:00Z' <= valid_time <= '2026-09-24T18:00:00Z':
        continue
    row = dict(valid_time=valid_time, latitude=item['latitude'], longitude=item['longitude'])
    for field in ('low_cloud_cover', 'medium_cloud_cover', 'high_cloud_cover', 'total_cloud_cover'):
        row[field + '_pct'] = {s: item[field + '_' + s] * 100 for s in ('mean', 'p10', 'p90')}
    row['wind_speed_10m_kt'] = {s: item['wind_speed_10m_' + s] * KNOTS for s in ('mean', 'p10', 'p90')}
    row['temperature_2m_c'] = {s: item['temperature_2m_' + s] - 273.15 for s in ('mean', 'p10', 'p90')}
    row['dewpoint_2m_c'] = {s: item['dewpoint_temperature_2m_' + s] - 273.15 for s in ('mean', 'p10', 'p90')}
    surface.append(row)

time_summaries = []
for hi, valid_time in enumerate(source['valid_time']):
    low_rh = rh[:, hi, :3, 1, 1]
    freezing = []
    crossing_counts = []
    for member in range(64):
        tt = tc[member, hi, :, 1, 1]; zz = z[member, hi, :, 1, 1] / .3048
        crossings = np.flatnonzero((tt[:-1] > 0) & (tt[1:] <= 0))
        crossing_counts.append(len(crossings))
        if len(crossings):
            idx = crossings[0]
            freezing.append(float(zz[idx] + tt[idx] / (tt[idx] - tt[idx+1]) * (zz[idx+1] - zz[idx])))
    time_summaries.append(dict(valid_time=str(valid_time),
        members_any_sampled_low_level_rh_ge_80=int(np.sum(np.any(low_rh >= 80, axis=1))),
        members_any_sampled_low_level_rh_ge_90=int(np.sum(np.any(low_rh >= 90, axis=1))),
        members_1000_to_925_temperature_inversion=int(np.sum(tc[:, hi, 1, 1, 1] > tc[:, hi, 0, 1, 1])),
        members_925_to_850_temperature_inversion=int(np.sum(tc[:, hi, 2, 1, 1] > tc[:, hi, 1, 1, 1])),
        temperature_change_925_to_850_c=summary(tc[:, hi, 2, 1, 1] - tc[:, hi, 1, 1, 1]),
        freezing_height_ft_msl_interpolated=summary(freezing),
        members_with_freezing_crossing=len(freezing),
        max_freezing_crossings=max(crossing_counts),
        neighborhood_median_rh_pct_minmax={str(int(level)): [float(np.median(rh[:, hi, pi], axis=0).min()), float(np.median(rh[:, hi, pi], axis=0).max())] for pi, level in enumerate(source['pressure_hpa'])},
        neighborhood_median_wind_kt_minmax={str(int(level)): [float(np.median(speed[:, hi, pi], axis=0).min()), float(np.median(speed[:, hi, pi], axis=0).max())] for pi, level in enumerate(source['pressure_hpa'])}))

output = dict(init='2026-09-20T00:00:00Z', nearest_point={'latitude': 41.0, 'longitude': -74.25},
              rows=rows, time_summaries=time_summaries, surface_context=surface,
              surface_context_source=str(surface_cache.relative_to(REPO)),
              surface_context_source_sha256=hashlib.sha256(surface_cache.read_bytes()).hexdigest(),
              notes=['Native pressure profiles at 12Z and 18Z; no time interpolation.',
                     'RH over liquid water derived within each paired member using Bolton saturation vapor pressure.',
                     'RH threshold counts describe members at sampled levels, not cloud or ceiling probabilities.',
                     'Wind speed derived within each member before aggregation; direction is from ensemble mean U/V.',
                     'Heights are geopotential feet MSL, not AGL or standard-atmosphere pressure altitude.',
                     'Freezing height is an explicitly interpolated diagnostic between coarse vertical samples.',
                     'Some raw specific humidities are exactly zero. RH retains these as zero; dew point is undefined and omitted for those entries. Dew-point summary counts disclose the smaller sample.',
                     'Surface cloud context reuses cached BigQuery marginal summaries at 40.9N, 74.3W; not paired with pressure members.'])
(ROOT / 'diagnostics.json').write_text(json.dumps(output, indent=2) + '\n')
validation = dict(completed_at=datetime.now(timezone.utc).isoformat(),
                  complete_members=64, native_valid_times=source['valid_time'].tolist(),
                  native_pressure_levels=source['pressure_hpa'].tolist(), raw_variables=5,
                  retained_grid_shape=[3, 3], all_raw_values_finite=True,
                  zero_humidity_values_nearest_point=int(np.sum(q[:, :, :, 1, 1] == 0)),
                  zero_humidity_values_all_nine_points=int(np.sum(q == 0)),
                  undefined_dewpoints_are_missing=True,
                  all_heights_increase_as_pressure_falls=True,
                  max_q_roundtrip_error=float(np.max(abs(q_recovered-q))),
                  max_rh_bolton_vs_hyland_wexler_difference_pp=float(np.max(abs(rh-rh_hw))),
                  max_rh_pct=float(rh.max()),
                  median_abs_hydrostatic_thickness_difference_m=float(np.median(abs(dz_actual-dz_hydrostatic))),
                  max_abs_hydrostatic_thickness_difference_m=float(np.max(abs(dz_actual-dz_hydrostatic))),
                  max_relative_hydrostatic_thickness_difference_pct=float(np.max(abs(dz_actual-dz_hydrostatic)/dz_actual)*100))
(ROOT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
np.savez_compressed(ROOT / 'derived-profiles.npz', **derived, member=source['member'],
                    valid_time=source['valid_time'], pressure_hpa=source['pressure_hpa'],
                    latitude=source['latitude'], longitude=source['longitude'])
with (ROOT / 'member-profiles.csv').open('w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=['member', 'valid_time', 'pressure_hpa'] + list(derived))
    writer.writeheader()
    for member in range(64):
        for hi, valid_time in enumerate(source['valid_time']):
            for pi, level in enumerate(source['pressure_hpa']):
                writer.writerow(dict(member=member, valid_time=str(valid_time), pressure_hpa=int(level),
                                     **{k: float(v[member, hi, pi, 1, 1]) if np.isfinite(v[member, hi, pi, 1, 1]) else None for k, v in derived.items()}))
print(json.dumps(validation, indent=2))
for row in rows:
    print(row['valid_time'], row['pressure_hpa'],
          'height', round(row['height_ft_msl']['median']),
          'T', round(row['temperature_c']['median'], 1),
          'Td', round(row['dewpoint_c']['median'], 1),
          'RH', [round(row['relative_humidity_water_pct'][s]) for s in ('p10', 'median', 'p90')],
          'wind', [round(row['wind_speed_kt'][s], 1) for s in ('p10', 'median', 'p90')],
          'dir', round(row['wind_direction']['mean_vector_from_deg_true']),
          'nRH90', row['members_rh_ge_90'])
print(json.dumps(time_summaries, indent=2))
