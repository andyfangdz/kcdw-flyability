from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from datetime import datetime, timedelta, timezone
import hashlib, json
from pathlib import Path
import numpy as np
import zstandard
from kcdw.weathernext3_zarr import GrpcStore
ROOT=Path(__file__).resolve().parent
class EnsembleStore(GrpcStore):
    @property
    def bucket_path(self):return 'projects/_/buckets/weathernext3_spatial'
store=EnsembleStore(project='aviation-486817')
prefix='weathernext_3_0_0/zarr/2026_to_present/20260920_00hr_01_preds/predictions.zarr'
metadata=json.loads((ROOT/'20260920T00Z-zarr.json').read_text())['consolidated_metadata']['metadata']
coordinates={}
for key in ('sample','lead_time','lead_subtime','lat_0p1','lon_0p1','init_time'):
    meta=metadata[key];name=f'{prefix}/{key}/c'+('/0' if meta['shape'] else '')
    info=store.info(name);assert info.size<100000
    raw,_=store.read_object(name,info)
    decoded=zstandard.ZstdDecompressor().decompress(raw)
    dtype='<f4' if meta['data_type']=='float32' else '<i8'
    values=np.frombuffer(decoded,dtype=dtype).reshape(meta['shape']);coordinates[key]=values
    print(key,values.tolist() if values.size<100 else [float(values.min()),float(values.max())],flush=True)
np.savez_compressed(ROOT/'coordinates.npz',**coordinates)
lead=114
index=int(np.flatnonzero(coordinates['lead_time']==lead)[0])
assert coordinates['sample'].shape==(64,) and len(set(coordinates['sample']))==64
assert list(coordinates['lead_subtime'])==[-5,-4,-3,-2,-1,0]

def info_for(member):
    name=f'{prefix}/mean_sea_level_pressure/c/{member}/{index}/0/0/0'
    info=store.info(name)
    return dict(member_index=member,member_id=int(coordinates['sample'][member]),name=name,**asdict(info))
with ThreadPoolExecutor(max_workers=8) as pool:objects=list(pool.map(info_for,range(64)))
manifest=dict(bucket='weathernext3_spatial',init='2026-09-20T00:00:00Z',lead_index=index,lead_time_hours=lead,lead_subtime_hours=coordinates['lead_subtime'].tolist(),valid_hours=[(datetime(2026,9,20,tzinfo=timezone.utc)+timedelta(hours=lead+int(v))).isoformat() for v in coordinates['lead_subtime']],variable='mean_sea_level_pressure',source_unit='Pa',objects=objects,total_compressed_bytes=sum(o['size'] for o in objects),total_decoded_bytes=64*6*1801*3600*4,checked_at=datetime.now(timezone.utc).isoformat())
(ROOT/'pressure-member-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('64 MEMBERS PRESENT; TOTAL COMPRESSED BYTES',manifest['total_compressed_bytes'],'MEMBER BYTE RANGE',min(o['size'] for o in objects),max(o['size'] for o in objects),flush=True)
