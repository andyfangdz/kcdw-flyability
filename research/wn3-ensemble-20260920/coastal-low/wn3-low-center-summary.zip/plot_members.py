from pathlib import Path
import json,os
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
os.environ.setdefault('MPLCONFIGDIR',str(REPO/'var/charts/.matplotlib'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import cartopy
import cartopy.crs as ccrs
import cartopy.feature as cf
from scipy.ndimage import gaussian_filter
cartopy.config['data_dir']=str(REPO/'var/charts/cartopy-data')
d=json.loads((ROOT/'center-diagnostics.json').read_text())
selected=[r['selected'] for r in d['rows']]
others=[c for r in d['rows'] for c in r['candidates'][1:]]
mean=d['mean_field_centers'][0]
with np.load(ROOT/'regional-ensemble-summary.npz') as summary:
    xx,yy=np.meshgrid(summary['longitude'],summary['latitude']);pressure=gaussian_filter(summary['mean_pressure_pa'][2]/100,sigma=2.5)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11})
fig=plt.figure(figsize=(13,9.4),facecolor='white')
proj=ccrs.LambertConformal(central_longitude=-68,central_latitude=35,standard_parallels=(30,40))
ax=fig.add_axes([.045,.19,.91,.65],projection=proj)
ax.set_extent([-82,-54,26,44],crs=ccrs.PlateCarree())
ax.add_feature(cf.LAND.with_scale('50m'),facecolor='#f1f3f4',edgecolor='none',zorder=0)
ax.coastlines('50m',linewidth=.75,color='#6f7c84')
ax.add_feature(cf.STATES.with_scale('50m'),edgecolor='#a2acb4',linewidth=.4)
cs=ax.contour(xx,yy,pressure,levels=np.arange(1000,1040,4),transform=ccrs.PlateCarree(),colors='#b8c4cd',linewidths=.85)
ax.clabel(cs,fmt='%d',fontsize=9)
ax.scatter([c['longitude'] for c in others],[c['latitude'] for c in others],s=35,facecolors='none',edgecolors='#8596a3',linewidths=.85,alpha=.8,transform=ccrs.PlateCarree(),zorder=4)
ax.scatter([c['longitude'] for c in selected],[c['latitude'] for c in selected],s=41,facecolors='#266da4',edgecolors='white',linewidths=.65,alpha=.82,transform=ccrs.PlateCarree(),zorder=5)
ax.scatter(mean['longitude'],mean['latitude'],s=155,marker='D',facecolors='#c36331',edgecolors='white',linewidths=1.5,transform=ccrs.PlateCarree(),zorder=7)
ax.text(-75.9,41.1,'New Jersey',fontsize=10,color='#576978',transform=ccrs.PlateCarree())
ax.text(-79.4,34.7,'Carolinas',fontsize=10,color='#576978',transform=ccrs.PlateCarree())
x,y=proj.transform_point(mean['longitude'],mean['latitude'],ccrs.PlateCarree())
ax.annotate('Ensemble-mean low\n~1010 hPa',(x,y),xytext=(-140,70),textcoords='offset points',fontsize=11,color='#a34f26',weight='bold',bbox=dict(facecolor='white',edgecolor='none',alpha=.9),arrowprops=dict(arrowstyle='-',color='#c36331'),zorder=8)
fig.text(.055,.96,'WN3 ensemble: coastal-low positions Thursday morning',fontsize=22,weight='bold',color='#243b4c')
fig.text(.055,.918,'64 members  •  Init 20 Sep 2026, 00 UTC  •  Valid Thu 24 Sep, 11:00 EDT (15 UTC)',fontsize=12,color='#526a7b')
fig.text(.055,.875,'A single-hour view of low centers; 37 of 64 members contain more than one detected minimum.',fontsize=11,color='#3c5263')
legend=[Line2D([],[],marker='o',linestyle='',markerfacecolor='#266da4',markeredgecolor='white',markersize=8,label='Deepest detected low per member'),Line2D([],[],marker='o',linestyle='',markerfacecolor='none',markeredgecolor='#8596a3',markersize=7,label='Other detected minima'),Line2D([],[],marker='D',linestyle='',markerfacecolor='#c36331',markeredgecolor='white',markersize=8,label='Low in ensemble-mean field')]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.135),ncol=3,frameon=False,fontsize=10)
fig.text(.055,.105,'Deepest-center distance from KCDW: median ~1,060 km; middle 80% of members ~850–1,230 km.',fontsize=11,color='#344c5e')
fig.text(.055,.068,'Method: 0.25° smoothing; local pressure minima ≤1018 hPa within 27–42°N, 80–55°W. Gray contours show mean pressure.',fontsize=9,color='#5c6c77')
fig.text(.055,.045,'Centers have not been linked into storm tracks. These are ensemble samples, not calibrated probabilities of local impacts.',fontsize=9,color='#5c6c77')
fig.text(.055,.022,'Source: Google WeatherNext 3 full-ensemble GCS Zarr. Boundaries: Natural Earth. Forecast subset and source checksums saved locally.',fontsize=9,color='#5c6c77')
fig.savefig(ROOT/'wn3-member-low-centers.png',dpi=230)
plt.close(fig)
print(ROOT/'wn3-member-low-centers.png')
