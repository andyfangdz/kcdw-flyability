import hashlib, json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from kcdw.weathernext3_zarr import GrpcStore
ROOT=Path(__file__).resolve().parent
class EnsembleStore(GrpcStore):
    @property
    def bucket_path(self):return 'projects/_/buckets/weathernext3_spatial'
store=EnsembleStore(project='aviation-486817')
results=[]
for hour in ('00','06'):
    name=f'weathernext_3_0_0/zarr/2026_to_present/20260920_{hour}hr_01_preds/predictions.zarr/zarr.json'
    result={'object':'gs://weathernext3_spatial/'+name,'checked_at':datetime.now(timezone.utc).isoformat(),'billing_project':'aviation-486817'}
    try:
        info=store.info(name);result['info']=asdict(info)
        if info.size>2000000:raise ValueError('Metadata exceeds 2 MB probe limit')
        raw,cached=store.read_object(name,info)
        target=ROOT/f'20260920T{hour}Z-zarr.json';target.write_bytes(raw)
        doc=json.loads(raw);metadata=doc.get('consolidated_metadata',{}).get('metadata',{})
        result.update(ok=True,sha256=hashlib.sha256(raw).hexdigest(),arrays=list(metadata))
        print('RUN',hour,'METADATA BYTES',len(raw),'ARRAYS',len(metadata),flush=True)
        for key,value in metadata.items():
            if key in ('sample','lead_time','lead_subtime','init_time','lat_0p1','lon_0p1') or 'mean_sea_level_pressure' in key:
                print(key,json.dumps(value),flush=True)
    except Exception as error:
        result.update(ok=False,error_type=type(error).__name__,error=str(error)[:800]);print(json.dumps(result),flush=True)
    results.append(result)
(ROOT/'access-results.json').write_text(json.dumps(results,indent=2)+'\n')
