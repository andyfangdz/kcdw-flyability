from pathlib import Path
import json, os
import numpy as np
from scipy.ndimage import gaussian_filter, minimum_filter
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
validation=json.loads((ROOT/'validation.json').read_text());assert validation['members']==64
with np.load(ROOT/'regional-ensemble-summary.npz') as d:
    LAT=d['latitude'];LON=d['longitude'];MEAN=d['mean_pressure_pa'][2]/100
XX,YY=np.meshgrid(LON,LAT)

def distance(lat,lon):
    y1=np.radians(lat);y2=np.radians(40.8752)
    a=np.sin((y1-y2)/2)**2+np.cos(y1)*np.cos(y2)*np.sin(np.radians(lon+74.2814)/2)**2
    return 6371*2*np.arcsin(np.sqrt(a))

def lows(pressure):
    smooth=gaussian_filter(pressure,sigma=2.5)
    mask=(smooth==minimum_filter(smooth,size=41))&(YY>=27)&(YY<=42)&(XX>=-80)&(XX<=-55)&(smooth<=1018)
    points=[]
    for i,j in np.argwhere(mask):
        points.append(dict(latitude=float(LAT[i]),longitude=float(LON[j]),pressure_hpa=float(smooth[i,j]),distance_kcdw_km=float(distance(LAT[i],LON[j]))))
    return sorted(points,key=lambda p:p['pressure_hpa'])

rows=[]
for i in range(64):
    with np.load(ROOT/f'member-{i:02d}-pressure.npz') as d:
        candidates=lows(d['pressure_pa'][2]/100)
        rows.append(dict(member=i,candidates=candidates,selected=candidates[0] if candidates else None))
mean_lows=lows(MEAN)
selected=[r['selected'] for r in rows if r['selected'] is not None]
result=dict(init=validation['init'],valid='2026-09-24T15:00:00Z',members=64,members_with_detected_low=len(selected),members_with_multiple_minima=sum(len(r['candidates'])>1 for r in rows),members_with_selected_center_within_500km=sum(p['distance_kcdw_km']<500 for p in selected),selected_pressure_hpa_range=[min(p['pressure_hpa'] for p in selected),max(p['pressure_hpa'] for p in selected)],distance_kcdw_km_p10_p50_p90=np.quantile([p['distance_kcdw_km'] for p in selected],[.1,.5,.9]).tolist(),mean_field_centers=mean_lows,method='At 15 UTC only: smooth each 0.1-degree MSLP field with Gaussian sigma 0.25 degrees; find local minima in a 4-degree neighborhood within 27–42N / 80–55W; retain minima <=1018 hPa, select the deepest per member. No temporal track association or closed-contour requirement. Secondary minima retained. This is a diagnostic sample distribution, not a calibrated probability.',rows=rows)
(ROOT/'center-diagnostics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
