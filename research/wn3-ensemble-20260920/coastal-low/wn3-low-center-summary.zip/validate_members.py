"""Verify member identity/time mapping by reconstructing published WN3 means."""
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
manifest=json.loads((ROOT/'pressure-member-manifest.json').read_text())
sum_pressure=None;points=[];identities=[]
for member in range(64):
    with np.load(ROOT/f'member-{member:02d}-pressure.npz',allow_pickle=False) as d:
        values=d['pressure_pa']
        assert values.shape==(6,221,351) and values.dtype==np.dtype('float32')
        assert int(d['member_id'])==member
        assert list(d['valid_time'])==manifest['valid_hours']
        assert np.isfinite(values).all()
        if member==0:
            lat,lon=d['latitude'].copy(),d['longitude'].copy()
            sum_pressure=np.zeros_like(values,dtype=np.float64)
            iy,ix=np.argmin(abs(lat-40.9)),np.argmin(abs(lon+74.3))
        else:
            assert np.array_equal(d['latitude'],lat) and np.array_equal(d['longitude'],lon)
        sum_pressure+=values
        points.append(values[:,iy,ix].copy())
        identities.append(int(d['member_id']))
assert identities==list(range(64))
mean_pa=sum_pressure/64
with np.load(REPO/'var/research/coastal-low-20260920/wn3-20260920T00Z-f114.npz') as published:
    iy=[int(np.argmin(abs(published['latitude']-v))) for v in lat]
    ix=[int(np.argmin(abs(published['longitude']-v))) for v in lon]
    assert np.allclose(published['latitude'][iy],lat,atol=1e-5,rtol=0)
    assert np.allclose(published['longitude'][ix],lon,atol=4e-5,rtol=0)
    expected=published['pressure_hpa'][np.ix_(iy,ix)]
    differences=mean_pa[-1]/100-expected
    assert np.max(abs(differences))<.005
raw_point=np.array(points,dtype=np.float64)
packet=json.loads((REPO/'var/wn3-bigquery/0e4fb4acdcc85b7950cd2d4417aa8943d72685cfdd95cc929d1450d304d8e597.json').read_text())
byhour={r['hours']:r for r in packet['rows']}
point_results=[]
for j,h in enumerate(range(109,115)):
    expected=byhour[h]['mean_sea_level_pressure_mean']/100
    actual=float(raw_point[:,j].mean()/100)
    assert abs(actual-expected)<.005
    quantiles=np.quantile(raw_point[:,j],[.1,.9])/100
    expected_quantiles=[byhour[h]['mean_sea_level_pressure_p10']/100,byhour[h]['mean_sea_level_pressure_p90']/100]
    point_results.append(dict(lead_hour=h,member_mean_hpa=actual,published_mean_hpa=expected,mean_difference_hpa=actual-expected,member_p10_p90_hpa=quantiles.tolist(),published_p10_p90_hpa=expected_quantiles))
result=dict(members=64,hours=6,field='mean_sea_level_pressure',init=manifest['init'],valid_hours=manifest['valid_hours'],all_members_finite=True,unique_member_ids=identities,regional_mean_verification=dict(valid=manifest['valid_hours'][-1],grid_points=221*351,max_abs_difference_hpa=float(np.max(abs(differences))),rmse_hpa=float(np.sqrt(np.mean(differences**2)))),kcdw_verification=point_results,comparison_scope='Regional mean at 18 UTC against previously read statistics Zarr; six hourly KCDW means against previously cached BigQuery, with no new query.')
(ROOT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
np.savez_compressed(ROOT/'regional-ensemble-summary.npz',mean_pressure_pa=mean_pa,latitude=lat,longitude=lon,valid_time=np.array(manifest['valid_hours']),kcdw_member_pressure_pa=raw_point,member_id=np.arange(64))
print(json.dumps(result,indent=2))
