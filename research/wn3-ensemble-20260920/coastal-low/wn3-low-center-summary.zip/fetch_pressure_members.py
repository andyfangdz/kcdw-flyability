"""Bounded raw WN3 pressure extraction for one six-hour block and 64 members."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib, json, sys
from pathlib import Path
import numpy as np
import zstandard
from kcdw.weathernext3_zarr import GrpcStore, ObjectInfo
ROOT=Path(__file__).resolve().parent
class EnsembleStore(GrpcStore):
    @property
    def bucket_path(self):return 'projects/_/buckets/weathernext3_spatial'
manifest=json.loads((ROOT/'pressure-member-manifest.json').read_text())
assert manifest['total_compressed_bytes']<=7300000000
assert len(manifest['objects'])==64 and manifest['lead_time_hours']==114
meta=json.loads((ROOT/'20260920T00Z-zarr.json').read_text())['consolidated_metadata']['metadata']['mean_sea_level_pressure']
assert meta['shape']==[64,60,6,1801,3600] and meta['chunk_grid']['configuration']['chunk_shape']==[1,1,6,1801,3600]
assert meta['data_type']=='float32' and meta['attributes']['units']=='Pa'
assert meta['dimension_names']==['sample','lead_time','lead_subtime','lat_0p1','lon_0p1']
assert meta['codecs']==[{'name':'bytes','configuration':{'endian':'little'}},{'name':'zstd','configuration':{'level':0,'checksum':False}}]
with np.load(ROOT/'coordinates.npz',allow_pickle=False) as c:
    lat=c['lat_0p1'];lon=(c['lon_0p1']+180)%360-180
    assert np.allclose(lat,np.linspace(-90,90,1801),rtol=0,atol=1e-5)
    assert np.allclose(c['lon_0p1'],np.arange(3600)/10,rtol=0,atol=4e-5)
    assert np.array_equal(c['sample'],np.arange(64))
    assert np.array_equal(c['lead_subtime'],[-5,-4,-3,-2,-1,0])
iy=np.flatnonzero((lat>=26)&(lat<=48));ix=np.flatnonzero((lon>=-85)&(lon<=-50));ix=ix[np.argsort(lon[ix])]
store=EnsembleStore(project='aviation-486817')

def fetch(item):
    target=ROOT/f'member-{item["member_index"]:02d}-pressure.npz'
    proof_file=target.with_suffix('.json')
    if target.exists() and proof_file.exists():
        proof=json.loads(proof_file.read_text())
        assert hashlib.sha256(target.read_bytes()).hexdigest()==proof['regional_sha256']
        assert proof['object']==item
        return proof
    info=ObjectInfo(size=item['size'],generation=item['generation'],crc32c=item['crc32c'])
    assert info.size<120000000
    encoded,_=store.read_object(item['name'],info)
    expected=6*1801*3600*4
    raw=zstandard.ZstdDecompressor().decompress(encoded,max_output_size=expected)
    assert len(raw)==expected
    planes=np.frombuffer(raw,dtype='<f4').reshape(6,1801,3600)
    regional=planes[:,iy][:,:,ix].copy()
    assert np.isfinite(regional).all() and regional.min()>75000 and regional.max()<115000
    temporary=target.with_suffix('.tmp.npz')
    np.savez_compressed(temporary,pressure_pa=regional,latitude=lat[iy],longitude=lon[ix],valid_time=np.array(manifest['valid_hours']),member_id=item['member_id'])
    temporary.replace(target)
    proof=dict(object=item,bucket=manifest['bucket'],init=manifest['init'],valid_hours=manifest['valid_hours'],shape=list(regional.shape),units='Pa',source_sha256=hashlib.sha256(encoded).hexdigest(),regional_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),download_bytes=len(encoded),saved_bytes=target.stat().st_size,retrieved_at=datetime.now(timezone.utc).isoformat())
    proof_file.write_text(json.dumps(proof,indent=2)+'\n')
    return proof

items=manifest['objects'][:1] if '--pilot' in sys.argv else manifest['objects']
results=[]
with ThreadPoolExecutor(max_workers=3) as pool:
    futures={pool.submit(fetch,item):item['member_index'] for item in items}
    for f in as_completed(futures):
        proof=f.result();results.append(proof)
        print('MEMBER',proof['object']['member_id'],'OK',len(results),'/',len(items),'saved',proof['saved_bytes'],flush=True)
results.sort(key=lambda r:r['object']['member_index'])
if len(results)==64:
    assert [r['object']['member_id'] for r in results]==list(range(64))
    total=dict(init=manifest['init'],valid_hours=manifest['valid_hours'],members=64,variable='mean_sea_level_pressure',units='Pa',bounds={'south':26,'north':48,'west':-85,'east':-50},compressed_source_bytes=sum(r['download_bytes'] for r in results),regional_file_bytes=sum(r['saved_bytes'] for r in results),source_bucket=manifest['bucket'],members_provenance=[f'member-{i:02d}-pressure.json' for i in range(64)],completed_at=datetime.now(timezone.utc).isoformat())
    (ROOT/'extraction.json').write_text(json.dumps(total,indent=2)+'\n')
    print(json.dumps(total),flush=True)
